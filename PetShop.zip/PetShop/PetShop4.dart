import 'dart:io';

abstract class Exibivel {
  void exibir();
}

abstract class ItemPetShop implements Exibivel {
  int codigo;
  String nome;
  double _preco;

  ItemPetShop(this.codigo, this.nome, this._preco);

  double get preco => _preco;

  set preco(double novoPreco) {
    if (novoPreco > 0) {
      _preco = novoPreco;
    }
  }

  @override
  void exibir();
}

class Produto extends ItemPetShop {
  Produto(int codigo, String nome, double preco) : super(codigo, nome, preco);

  @override
  void exibir() {
    print('Produto $codigo - $nome - R\$ ${preco.toStringAsFixed(2)}');
  }
}

class Servico extends ItemPetShop {
  Servico(int codigo, String nome, double preco) : super(codigo, nome, preco);

  @override
  void exibir() {
    print('Servico $codigo - $nome - R\$ ${preco.toStringAsFixed(2)}');
  }
}

class Cliente {
  String nome;

  Cliente(this.nome);
}

class Carrinho {
  List<ItemPetShop> itens = [];

  void adicionar(ItemPetShop item) {
    if (itens.length >= 3) {
      print('Seu carrinho de compras ja esta cheio.');
    } else {
      itens.add(item);
      print('${item.nome} adicionado ao carrinho!');
    }
  }

  void listar() {
    print('\n--- SEU CARRINHO ---');

    if (itens.isEmpty) {
      print('O carrinho esta vazio.');
    } else {
      for (ItemPetShop item in itens) {
        print('- ${item.nome} - R\$ ${item.preco.toStringAsFixed(2)}');
      }

      print('Total atual: R\$ ${calcularTotal().toStringAsFixed(2)}');
    }
  }

  double calcularTotal() {
    double total = 0;

    for (ItemPetShop item in itens) {
      total += item.preco;
    }

    return total;
  }

  void limpar() {
    itens.clear();
  }
}

void exibirMenuPrincipal(String nome) {
  print('\nOla $nome, escolha uma opcao:');
  print('1 - Ver promocoes');
  print('2 - Solicitar servico');
  print('3 - Listar carrinho');
  print('4 - Finalizar compra');
  print('0 - Sair');
  print('Digite sua opcao: ');
}

void exibirLista(String titulo, List<ItemPetShop> itens) {
  print('\n--- $titulo ---');

  for (ItemPetShop item in itens) {
    item.exibir();
  }

  print('8 - Adicionar ao carrinho');
  print('0 - Voltar');
}

ItemPetShop? buscarItemPorCodigo(List<ItemPetShop> itens, int codigo) {
  for (ItemPetShop item in itens) {
    if (item.codigo == codigo) {
      return item;
    }
  }

  return null;
}

void adicionarItemAoCarrinho(Carrinho carrinho, List<ItemPetShop> itens) {
  print('Digite o codigo do item que deseja adicionar: ');
  int codigo = int.parse(stdin.readLineSync()!);

  ItemPetShop? item = buscarItemPorCodigo(itens, codigo);

  if (item == null) {
    print('Codigo invalido.');
  } else {
    carrinho.adicionar(item);
  }
}

void finalizarCompra(Carrinho carrinho, Cliente cliente) {
  if (carrinho.itens.isEmpty) {
    print('\nSeu carrinho esta vazio! Adicione itens antes de finalizar.');
    return;
  }

  double total = carrinho.calcularTotal();

  print('\n--- FINALIZACAO DE PEDIDO ---');
  print('Valor total dos itens: R\$ ${total.toStringAsFixed(2)}');
  print('Escolha a forma de pagamento:');
  print('1 - Dinheiro (10% de desconto)');
  print('2 - Cartao (valor integral)');
  print('Digite sua opcao: ');

  int formaPagamento = int.parse(stdin.readLineSync()!);
  double valorFinal = total;

  if (formaPagamento == 1) {
    valorFinal = total * 0.90;
    print('\nDesconto aplicado: R\$ ${(total - valorFinal).toStringAsFixed(2)}');
  } else if (formaPagamento != 2) {
    print('Opcao de pagamento invalida.');
    return;
  }

  print('\n--- RECIBO ---');
  print('VALOR A PAGAR: R\$ ${valorFinal.toStringAsFixed(2)}');
  print('Obrigado pela preferencia, ${cliente.nome}!');
  carrinho.limpar();
}

void areaRestrita() {
  print('\nArea restrita dos funcionarios.');
  print('Digite o nome do cliente: ');
  String nomeCliente = stdin.readLineSync()!;

  print('Digite o valor gasto na loja: ');
  double valorGasto = double.parse(stdin.readLineSync()!);

  print('Digite a forma de pagamento (D - dinheiro ou C - cartao): ');
  String formaPagamento = stdin.readLineSync()!.toUpperCase();

  double valorFinal;

  if (formaPagamento == 'D') {
    valorFinal = valorGasto * 0.90;
    print('Desconto de 10% aplicado.');
  } else if (formaPagamento == 'C') {
    valorFinal = valorGasto;
  } else {
    print('Forma de pagamento invalida.');
    return;
  }

  print('Cliente: $nomeCliente');
  print('Valor final a ser pago: R\$ ${valorFinal.toStringAsFixed(2)}');
  print('Obrigado!');
}

void main() {
  List<ItemPetShop> promocoes = [
    Produto(101, 'Racao Royal Canin para caes', 290.00),
    Produto(102, 'Racao Royal Canin para gatos', 492.00),
    Produto(103, 'Bifinho Keldog', 23.92),
    Produto(104, 'Fraldas descartaveis para caes', 38.61),
  ];

  List<ItemPetShop> servicos = [
    Servico(201, 'Banho e tosa', 55.99),
    Servico(202, 'Tosa higienica', 12.99),
    Servico(203, 'Hidratacao dos pelos', 20.99),
  ];

  Carrinho carrinho = Carrinho();
  int opcaoPrincipal;

  print('Bem-vindo ao autoatendimento do CuidaPet');
  print('Por gentileza, digite seu nome: ');
  Cliente cliente = Cliente(stdin.readLineSync()!);

  if (cliente.nome == 'cuidapetrestrito') {
    areaRestrita();
    return;
  }

  do {
    exibirMenuPrincipal(cliente.nome);
    opcaoPrincipal = int.parse(stdin.readLineSync()!);

    switch (opcaoPrincipal) {
      case 1:
        int opcaoPromocao;

        do {
          exibirLista('PROMOCOES DO DIA', promocoes);
          print('Escolha uma opcao: ');
          opcaoPromocao = int.parse(stdin.readLineSync()!);

          if (opcaoPromocao == 8) {
            adicionarItemAoCarrinho(carrinho, promocoes);
          }
        } while (opcaoPromocao != 0);
        break;

      case 2:
        int opcaoServico;

        do {
          exibirLista('SERVICOS DISPONIVEIS', servicos);
          print('Escolha uma opcao: ');
          opcaoServico = int.parse(stdin.readLineSync()!);

          if (opcaoServico == 8) {
            adicionarItemAoCarrinho(carrinho, servicos);
          }
        } while (opcaoServico != 0);
        break;

      case 3:
        carrinho.listar();
        break;

      case 4:
        finalizarCompra(carrinho, cliente);
        break;

      case 0:
        print('Saindo... Obrigado por usar o CuidaPet!');
        break;

      default:
        print('Opcao invalida.');
    }
  } while (opcaoPrincipal != 0);
}
